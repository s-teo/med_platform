from rest_framework import generics
from .models import ChatMessage
from .serializers import ChatMessageSerializer
from rest_framework import permissions

class ChatMessageListAPIView(generics.ListAPIView):
    permission_classes = (permissions.IsAuthenticated,)
    serializer_class = ChatMessageSerializer

    def get_queryset(self):
        room_name = self.kwargs['room_name']
        return ChatMessage.objects.filter(room_name=room_name).order_by('timestamp')


class ChatMessageCreateAPIView(generics.CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    queryset = ChatMessage.objects.all()
    serializer_class = ChatMessageSerializer


class PrivateChatMessageListAPIView(generics.ListAPIView):
    permission_classes = (permissions.IsAuthenticated,)
    serializer_class = ChatMessageSerializer

    def get_queryset(self):
        recipient_id = self.kwargs['recipient_id']
        sender = self.request.user
        room_name = f"private_{min(sender.id, int(recipient_id))}_{max(sender.id, int(recipient_id))}"
        return ChatMessage.objects.filter(room_name=room_name).order_by('timestamp')
